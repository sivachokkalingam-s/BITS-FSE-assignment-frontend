package com.fse.equipment_management.data;

public enum UserRole {
    ADMIN,
    STAFF,
    STUDENT
}
